#include "tfUI.h"

namespace tf {

// ===================== RECT =========================

Rect::Rect(TFT_eSPI& display, int16_t w, int16_t h)
  : tft(display),
    x(0), y(0), width(w), height(h),
    fillColor(TFT_RED),
    outlineColor(TFT_WHITE),
    outlineThickness(1),
    fillEnabled(true),
    visible(true) {}

void Rect::setPosition(int16_t px, int16_t py) {
  x = px;
  y = py;
}

void Rect::setFillColor(uint16_t c) {
  fillColor = c;
  fillEnabled = true;
}

void Rect::disableFill() {
  fillEnabled = false;
}

void Rect::setOutlineColor(uint16_t c) {
  outlineColor = c;
}

void Rect::setOutlineThickness(uint8_t t) {
  outlineThickness = t;
}

void Rect::setVisible(bool v) {
  visible = v;
}

void Rect::draw() {
  if (!visible) return;

  if (fillEnabled)
    tft.fillRect(x, y, width, height, fillColor);

  if (outlineThickness > 0) {
    for (int i = 0; i < outlineThickness; i++) {
      tft.drawRect(x + i, y + i,
                   width - 2 * i,
                   height - 2 * i,
                   outlineColor);
    }
  }
}

void Rect::clear() {
  tft.fillRect(x, y, width, height, TFT_BLACK);
}

bool Rect::isClicked(XPT2046_Touchscreen& ts) {
  if (!ts.touched()) return false;

  TS_Point p = ts.getPoint();
  int16_t tx = map(p.x, 0, 4095, 0, tft.width());
  int16_t ty = map(p.y, 0, 4095, tft.height(), 0);

  return (tx >= x && tx <= x + width &&
          ty >= y && ty <= y + height);
}


// ===================== CIRCLE =========================

Circle::Circle(TFT_eSPI& display, int16_t r)
  : tft(display),
    x(0), y(0), radius(r),
    fillColor(TFT_BLUE),
    outlineColor(TFT_WHITE),
    outlineThickness(1),
    fillEnabled(true),
    visible(true) {}

void Circle::setPosition(int16_t px, int16_t py) {
  x = px;
  y = py;
}

void Circle::setFillColor(uint16_t c) {
  fillColor = c;
  fillEnabled = true;
}

void Circle::disableFill() {
  fillEnabled = false;
}

void Circle::setOutlineColor(uint16_t c) {
  outlineColor = c;
}

void Circle::setOutlineThickness(uint8_t t) {
  outlineThickness = t;
}

void Circle::setVisible(bool v) {
  visible = v;
}

void Circle::draw() {
  if (!visible) return;

  if (fillEnabled)
    tft.fillCircle(x, y, radius, fillColor);

  if (outlineThickness > 0) {
    for (int i = 0; i < outlineThickness; i++) {
      tft.drawCircle(x, y, radius - i, outlineColor);
    }
  }
}

void Circle::clear() {
  tft.fillCircle(x, y, radius, TFT_BLACK);
}

bool Circle::isClicked(XPT2046_Touchscreen& ts) {
  if (!ts.touched()) return false;

  TS_Point p = ts.getPoint();
  int16_t tx = map(p.x, 0, 4095, 0, tft.width());
  int16_t ty = map(p.y, 0, 4095, tft.height(), 0);

  int dx = tx - x;
  int dy = ty - y;

  return (dx*dx + dy*dy <= radius*radius);
}


// ===================== ROUNDED RECT =========================

RoundedRect::RoundedRect(TFT_eSPI& display, int16_t w, int16_t h, int16_t r)
  : tft(display),
    x(0), y(0), width(w), height(h), radius(r),
    fillColor(TFT_GREEN),
    outlineColor(TFT_WHITE),
    outlineThickness(1),
    fillEnabled(true),
    visible(true) {}

void RoundedRect::setPosition(int16_t px, int16_t py) {
  x = px;
  y = py;
}

void RoundedRect::setFillColor(uint16_t c) {
  fillColor = c;
  fillEnabled = true;
}

void RoundedRect::disableFill() {
  fillEnabled = false;
}

void RoundedRect::setOutlineColor(uint16_t c) {
  outlineColor = c;
}

void RoundedRect::setOutlineThickness(uint8_t t) {
  outlineThickness = t;
}

void RoundedRect::setVisible(bool v) {
  visible = v;
}

void RoundedRect::draw() {
  if (!visible) return;

  if (fillEnabled)
    tft.fillRoundRect(x, y, width, height, radius, fillColor);

  if (outlineThickness > 0) {
    for (int i = 0; i < outlineThickness; i++) {
      tft.drawRoundRect(x + i, y + i,
                        width - 2 * i,
                        height - 2 * i,
                        radius - i,
                        outlineColor);
    }
  }
}

void RoundedRect::clear() {
  tft.fillRoundRect(x, y, width, height, radius, TFT_BLACK);
}

bool RoundedRect::isClicked(XPT2046_Touchscreen& ts) {
  if (!ts.touched()) return false;

  TS_Point p = ts.getPoint();
  int16_t tx = map(p.x, 0, 4095, 0, tft.width());
  int16_t ty = map(p.y, 0, 4095, tft.height(), 0);

  return (tx >= x && tx <= x + width &&
          ty >= y && ty <= y + height);
}


// ===================== TEXT =========================

Text::Text(TFT_eSPI& display, int16_t size)
  : tft(display),
    x(0), y(0), textSize(size),
    color(TFT_BLACK),
    bgColor(TFT_WHITE),
    visible(true),
    text("") {}

void Text::setPosition(int16_t px, int16_t py) {
  x = px;
  y = py;
}

void Text::setColor(uint16_t c) {
  color = c;
}

void Text::setbgColor(uint16_t q) {
  bgColor = q;
}

void Text::setString(const String& s) {
  setText(s);
}

void Text::setText(const String& s) {
  text = s;
}

void Text::setVisible(bool v) {
  visible = v;
}

void Text::draw() {
  if (!visible || text.length() == 0) return;

  int w = text.length() * 6 * textSize;
  int h = 8 * textSize;
  tft.fillRect(x, y, w, h, bgColor);

  tft.setCursor(x, y);
  tft.setTextSize(textSize);
  tft.setTextColor(color, bgColor);
  tft.print(text);
}

void Text::clear() {
  if (text.length() == 0) return;

  int w = text.length() * 6 * textSize;
  int h = 8 * textSize;

  tft.fillRect(x, y, w, h, bgColor);
}


// ===================== IMAGE HEX =========================

ImageHEX::ImageHEX(TFT_eSPI& display, const uint16_t* data, int16_t w, int16_t h)
    : tft(display), img(data), x(0), y(0), width(w), height(h), visible(true) {}

void ImageHEX::setPosition(int16_t px, int16_t py) {
    x = px;
    y = py;
}

void ImageHEX::setVisible(bool v) {
    visible = v;
}

void ImageHEX::clear() {
    tft.fillRect(x, y, width, height, TFT_WHITE);
}

void ImageHEX::draw() {
    if (!visible) return;

    tft.startWrite();

    for (int16_t j = 0; j < height; j++) {
        for (int16_t i = 0; i < width; i++) {
            uint16_t c = pgm_read_word(&img[j * width + i]);
            tft.drawPixel(x + i, y + j, c);
        }
        yield();
    }

    tft.endWrite();
}

bool ImageHEX::isClicked(XPT2046_Touchscreen& ts) {
    if (!ts.touched()) return false;

    TS_Point p = ts.getPoint();

    int16_t tx = map(p.x, 0, 4095, 0, tft.width());
    int16_t ty = map(p.y, 0, 4095, tft.height(), 0);

    return (tx >= x && tx <= x + width &&
            ty >= y && ty <= y + height);
}


// ===================== OPTION PANEL =========================

OptionPanel::OptionPanel(TFT_eSPI& display, XPT2046_Touchscreen& touch, int16_t w, int16_t h)
    : tft(display),
      ts(touch),
      x(0), y(0),
      width(w), height(h),
      expanded(false),
      visible(true),
      selectedIndex(-1),
      optionCount(0),
      bgColor(TFT_WHITE),
      textColor(TFT_BLACK),
      borderColor(TFT_BLUE),
      itemBgColor(0xC618)
{
}

void OptionPanel::setPosition(int16_t px, int16_t py) {
    x = px;
    y = py;
}

void OptionPanel::setColors(uint16_t bg, uint16_t txt, uint16_t border, uint16_t itemBg) {
    bgColor     = bg;
    textColor   = txt;
    borderColor = border;
    itemBgColor = itemBg;
}

void OptionPanel::setVisible(bool v) {
    visible = v;
}

void OptionPanel::add(const String& option) {
    if (optionCount < MAX_OPTIONS) {
        options[optionCount++] = option;
    }
}

void OptionPanel::clearOptions() {
    optionCount   = 0;
    selectedIndex = -1;
}

bool OptionPanel::hitMain(int16_t tx, int16_t ty) {
    return (tx >= x && tx <= x + width &&
            ty >= y && ty <= y + height);
}

int OptionPanel::hitItem(int16_t tx, int16_t ty) {
    if (!expanded) return -1;

    for (uint8_t i = 0; i < optionCount; i++) {
        int16_t oy = y + height * (i + 1);
        if (tx >= x && tx <= x + width &&
            ty >= oy && ty <= oy + height) {
            return (int)i;
        }
    }
    return -1;
}

void OptionPanel::draw() {
    if (!visible) return;

    tft.fillRect(x, y, width, height, bgColor);
    tft.drawRect(x, y, width, height, borderColor);

    tft.setCursor(x + 5, y + 5);
    tft.setTextSize(2);
    tft.setTextColor(textColor, bgColor);

    if (selectedIndex >= 0 && selectedIndex < optionCount)
        tft.print(options[selectedIndex]);
    else
        tft.print("Select...");

    if (expanded) {
        for (uint8_t i = 0; i < optionCount; i++) {
            int16_t oy = y + height * (i + 1);

            tft.fillRect(x, oy, width, height, itemBgColor);
            tft.drawRect(x, oy, width, height, borderColor);

            tft.setCursor(x + 5, oy + 5);
            tft.setTextSize(2);
            tft.setTextColor(textColor, itemBgColor);
            tft.print(options[i]);
        }
    }
}

void OptionPanel::clear() {
    if (!visible) return;

    int16_t totalHeight = height;
    if (expanded) {
        totalHeight = height * (optionCount + 1);
    }
    tft.fillRect(x, y, width, totalHeight, TFT_BLACK);
}

bool OptionPanel::update() {
    if (!visible) return false;
    if (!ts.touched()) return false;

    TS_Point p = ts.getPoint();
    int16_t tx = map(p.x, 0, 4095, 0, tft.width());
    int16_t ty = map(p.y, 0, 4095, tft.height(), 0);

    if (hitMain(tx, ty)) {
        expanded = !expanded;
        return true;
    }

    if (expanded) {
        int idx = hitItem(tx, ty);
        if (idx >= 0) {
            selectedIndex = idx;
            expanded = false;
            return true;
        }
    }

    return false;
}

int OptionPanel::get() {
    return selectedIndex;
}

String OptionPanel::getText() {
    if (selectedIndex >= 0 && selectedIndex < optionCount)
        return options[selectedIndex];
    return "";
}


// ===================== MAKE FUNCTIONS =========================

Rect makeRect(TFT_eSPI& tft, int16_t w, int16_t h) {
  return Rect(tft, w, h);
}

Circle makeCircle(TFT_eSPI& tft, int16_t radius) {
  return Circle(tft, radius);
}

RoundedRect makeRounded(TFT_eSPI& tft, int16_t w, int16_t h, int16_t r) {
  return RoundedRect(tft, w, h, r);
}

Text makeText(TFT_eSPI& tft, int16_t size) {
  return Text(tft, size);
}

} // namespace tf

#ifndef TF_UI_H
#define TF_UI_H

#include <TFT_eSPI.h>
#include <XPT2046_Touchscreen.h>
#include <pgmspace.h>

namespace tf {

// ===================== RECT =========================

class Rect {
public:
  Rect(TFT_eSPI& display, int16_t w, int16_t h);

  void setPosition(int16_t px, int16_t py);
  void setFillColor(uint16_t c);
  void disableFill();
  void setOutlineColor(uint16_t c);
  void setOutlineThickness(uint8_t t);
  void setVisible(bool v);
  void draw();
  void clear();
  bool isClicked(XPT2046_Touchscreen& ts);

private:
  TFT_eSPI& tft;
  int16_t x, y, width, height;
  uint16_t fillColor;
  uint16_t outlineColor;
  uint8_t outlineThickness;
  bool fillEnabled;
  bool visible;
};


// ===================== CIRCLE =========================

class Circle {
public:
  Circle(TFT_eSPI& display, int16_t r);

  void setPosition(int16_t px, int16_t py);
  void setFillColor(uint16_t c);
  void disableFill();
  void setOutlineColor(uint16_t c);
  void setOutlineThickness(uint8_t t);
  void setVisible(bool v);
  void draw();
  void clear();
  bool isClicked(XPT2046_Touchscreen& ts);

private:
  TFT_eSPI& tft;
  int16_t x, y, radius;
  uint16_t fillColor;
  uint16_t outlineColor;
  uint8_t outlineThickness;
  bool fillEnabled;
  bool visible;
};


// ===================== ROUNDED RECT =========================

class RoundedRect {
public:
  RoundedRect(TFT_eSPI& display, int16_t w, int16_t h, int16_t r);

  void setPosition(int16_t px, int16_t py);
  void setFillColor(uint16_t c);
  void disableFill();
  void setOutlineColor(uint16_t c);
  void setOutlineThickness(uint8_t t);
  void setVisible(bool v);
  void draw();
  void clear();
  bool isClicked(XPT2046_Touchscreen& ts);

private:
  TFT_eSPI& tft;
  int16_t x, y, width, height, radius;
  uint16_t fillColor;
  uint16_t outlineColor;
  uint8_t outlineThickness;
  bool fillEnabled;
  bool visible;
};


// ===================== TEXT =========================

class Text {
public:
  Text(TFT_eSPI& display, int16_t size);

  void setPosition(int16_t px, int16_t py);
  void setColor(uint16_t c);
  void setbgColor(uint16_t c);
  void setString(const String& s);
  void setText(const String& s);
  void setVisible(bool v);
  void draw();
  void clear();

private:
  TFT_eSPI& tft;
  int16_t x, y, textSize;
  uint16_t color;
  uint16_t bgColor;
  bool visible;
  String text;
};


// ===================== IMAGE HEX =========================

class ImageHEX {
public:
    ImageHEX(TFT_eSPI& display, const uint16_t* data, int16_t w, int16_t h);

    void setPosition(int16_t px, int16_t py);
    void setVisible(bool v);
    void clear();
    void draw();
    bool isClicked(XPT2046_Touchscreen& ts);

private:
    TFT_eSPI& tft;
    const uint16_t* img;
    int16_t x, y;
    int16_t width, height;
    bool visible;
};


// ===================== OPTION PANEL =========================

class OptionPanel {
public:
    OptionPanel(TFT_eSPI& display, XPT2046_Touchscreen& touch, int16_t w, int16_t h);

    void setPosition(int16_t px, int16_t py);
    void setColors(uint16_t bg, uint16_t txt, uint16_t border, uint16_t itemBg);
    void add(const String& option);
    void clearOptions();
    void setVisible(bool v);
    void draw();
    void clear();
    bool update();
    int  get();
    String getText();

private:
    static const uint8_t MAX_OPTIONS = 10;

    TFT_eSPI& tft;
    XPT2046_Touchscreen& ts;

    int16_t x, y, width, height;
    bool expanded;
    bool visible;
    int8_t selectedIndex;
    uint8_t optionCount;

    uint16_t bgColor;
    uint16_t textColor;
    uint16_t borderColor;
    uint16_t itemBgColor;

    String options[MAX_OPTIONS];

    bool hitMain(int16_t tx, int16_t ty);
    int  hitItem(int16_t tx, int16_t ty);
};


// ===================== MAKE FUNCTIONS =========================

Rect        makeRect   (TFT_eSPI& tft, int16_t w, int16_t h);
Circle      makeCircle (TFT_eSPI& tft, int16_t radius);
RoundedRect makeRounded(TFT_eSPI& tft, int16_t w, int16_t h, int16_t r);
Text        makeText   (TFT_eSPI& tft, int16_t size);

} // namespace tf

#endif
